package bank;
import java.util.*;
//import java.util.date;
import java.io.*;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
public class BankOperations {
static Connection conn =null;
static PreparedStatement pst =null;
static ResultSet rs = null;
long balance =1000;
static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
 void openAccount() throws NumberFormatException, IOException, SQLException {
	try {
	 conn = BankConncetionClass.getConnection();
	System.out.println("Enter Account number ");
	int ac_num = Integer.parseInt(br.readLine());
System.out.println("Enter account holder name ");
String acc_name = br.readLine();
System.out.println("Enter account type ");
String acc_type = br.readLine();


String s = "select * from AccountDetails2 where acc_no=?";
pst = conn.prepareStatement(s);
pst.setInt(1, ac_num);
rs= pst.executeQuery();
if(!rs.next()) {
	String s1 = "insert into AccountDetails2 values(?,?,?,?,CURRENT_TIMESTAMP)";
	pst = conn.prepareStatement(s1);
	pst.setInt(1,ac_num);
	pst.setString(2, acc_name);
	pst.setString(3,acc_type);
	pst.setLong(4,balance);
	int i = pst.executeUpdate();
	if(i > 0) {
		System.out.println(ac_num+ " Account created! ");
	}
	else {
		System.out.println("Account not created! ");
	}
}
else {
	System.out.println(ac_num+ "sry!already exists");
}
	}catch(Exception e) {
		e.printStackTrace();
	}
	finally {
		conn.close();
		pst.close();
	}
}
 public void Deposite() throws SQLException {
	 try {
	 conn = BankConncetionClass.getConnection();
		System.out.println("Enter Account number ");
		int ac_num = Integer.parseInt(br.readLine());
	System.out.println("Enter amount to be deposited ");
	long amt = Long.parseLong(br.readLine());
	String s = "select * from AccountDetails2 where acc_no=?";
	pst = conn.prepareStatement(s);
	pst.setInt(1, ac_num);
	rs= pst.executeQuery();
	if(rs.next()) {
		String up = "update AccountDetails2 set balance = balance + ? where acc_no=?";
		pst = conn.prepareStatement(up);
		pst.setLong(1,amt);
		pst.setInt(2,ac_num);
	 int i = pst.executeUpdate();
		if(i > 0) {
			System.out.println(" Your ammount deposited sucessfully! ");
		}
		else {
			System.out.println("not deposited ! ");
		}
	}
	else {
		System.out.println(ac_num+ "sry!Doesnot exists");
	}
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			conn.close();
			pst.close();
		}
	 
 }
 public void withDraw() throws NumberFormatException, IOException, SQLException {
	 try {
	  conn = BankConncetionClass.getConnection();
	 System.out.println("Enter Account number ");
	 int ac_num = Integer.parseInt(br.readLine());
		System.out.println("Enter amount to be withdraw ");
		long amt = Long.parseLong(br.readLine()); 
		String ss = "select * from AccountDetails2 where acc_no =?";
		pst = conn.prepareStatement(ss);
		pst.setInt(1, ac_num);
		rs = pst.executeQuery();
		if(rs.next()) {
			String depo = "update AccountDetails2 set balance = balance - ? where acc_no=?";
			pst = conn.prepareStatement(depo);
			pst.setLong(1, amt);
			pst.setInt(2, ac_num);
			int i =pst.executeUpdate();
			if(i >0) {
				System.out.println(" Your Account is Debited sucessfully! ");
			}
			else {
				System.out.println("Your balance is not sufficient ");
			}
		}
		else {
			System.out.println("sorry! Account doesn't exists");
		}
	 }catch(Exception e){
		 e.printStackTrace();
		 
	 }
	 finally {
		 pst.close();
		 conn.close();
	 }
 }
 public void displayAccountDetails() throws SQLException {
	 try {
	 conn = BankConncetionClass.getConnection();
	 String s = "select * from AccountDetails2;";
	 pst = conn.prepareStatement(s);
	 rs = pst.executeQuery();
	 System.out.println("AccountNumber\tAccountName\tAccountType\tBalance\tTranscation_date");
	 while(rs.next())
	 {
		 System.out.println(rs.getInt(1)+"\t      "+rs.getString(2)+" \t    "+rs.getString(3)+" \t      "+rs.getLong(4)+"\t   "+rs.getDate(5)+"\t ");
		
	 }
	 
 }
	 catch(Exception e) {
	 e.printStackTrace();
 }
	 finally {
		 pst.close();
		 conn.close();
	 }
 }
 

 public void deleteRecord() throws SQLException {
	 try {
		  conn = BankConncetionClass.getConnection();
		 System.out.println("Enter Account number to be deleted ");
		 int ac_num = Integer.parseInt(br.readLine());
			String ss = "select * from AccountDetails2 where acc_no =?";
			pst = conn.prepareStatement(ss);
			pst.setInt(1, ac_num);
			rs = pst.executeQuery();
			if(rs.next()) {
				String depo = "delete from AccountDetails2 where acc_no = ?";
				pst = conn.prepareStatement(depo);
				pst.setInt(1, ac_num);
				int i =pst.executeUpdate();
				if(i >0) {
					System.out.println(" Your Account deactivated! ");
				}
				else {
					System.out.println("Your Account not deactivated ");
				}
			}
			else {
				System.out.println("sorry! Account doesn't exists");
			}
		 }catch(Exception e){
			 e.printStackTrace();
			 
		 }
		 finally {
			 pst.close();
			 conn.close();
		 } 
 }
	 public void showParicularRecord() throws SQLException {
		 try {
		 conn = BankConncetionClass.getConnection();
		 BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
		 System.out.println("Enter account number");
		  int ac_num=Integer.parseInt(br.readLine());
		  String ss = "select * from AccountDetails2 where acc_no =?";
		  pst = conn.prepareStatement(ss);
			pst.setInt(1, ac_num);
			rs = pst.executeQuery();	
			System.out.println("AccountNumber\tAccountName\tAccountType\tBalance\tTranscation_date");
			 while(rs.next())
			 {
				 System.out.println(rs.getInt(1)+"\t      "+rs.getString(2)+" \t    "+rs.getString(3)+" \t      "+rs.getLong(4)+"\t   "+rs.getDate(5)+"\t ");
				
			 }
	 }catch(Exception e) {
		 e.printStackTrace();
	 }
		 finally {
			 pst.close();
			 conn.close();
		 }
		
	 
 }
	
	
	
	public static void main(String[] args) throws NumberFormatException, IOException, SQLException {
		BankOperations obj = new BankOperations();
		while(true) {
			System.out.println("**BANKApplication**");
			System.out.println("1.Create Account");
			System.out.println("2.Deposite Account");
			System.out.println("3.Withdraw Account");
			System.out.println("4.Display AccountDetails");
			System.out.println("5.Deactivate Account");
			System.out.println("6.Display particular Account");
			
			
			String name;
			int id;
			int n = Integer.parseInt(br.readLine());
			switch(n) {
			case 1:obj.openAccount();
			break;
			case 2:obj.Deposite();
           break;
			case 3:obj.withDraw();
			break;
			case 4:obj.displayAccountDetails();
			break;
			case 5:obj.deleteRecord();
			break;
			case 6:obj.showParicularRecord();
			break;
			
			
			
	}
System.out.println("Do you wanna continue Y/N");
char ch = br.readLine().toLowerCase().charAt(0);
if(ch =='n') {
	break;
}
}
		
}
}